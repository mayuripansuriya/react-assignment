import { userConstants } from '../_constants';

export function registration(state = {}, action) {
  console.log(action, '------')
  switch (action.type) {
    case userConstants.REGISTER_REQUEST:
      return { registering: true };
    case userConstants.REGISTER_SUCCESS:
      return {};
    case userConstants.REGISTER_FAILURE:
      return {
        errors:action.error
      };
    case userConstants.EDIT_REQUEST:
      return { registering: true };
    case userConstants.EDIT_SUCCESS:
      return {};
    case userConstants.EDIT_FAILURE:
      return {
        errors:action.error
      };
    default:
      return state
  }
}